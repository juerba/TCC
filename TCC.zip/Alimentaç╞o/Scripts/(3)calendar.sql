INSERT INTO [Calendar]
           ([service_id]
           ,[monday]
           ,[tuesday]
           ,[wednesday]
           ,[thursday]
           ,[friday]
           ,[saturday]
           ,[sunday]
           ,[start_date]
           ,[end_date])
     VALUES
           ('USD'
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1
           ,20120101
           ,20221231),
           
           ('US'
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1
           ,0
           ,20120101
           ,20221231),
           
           
           ('U'
           ,1
           ,1
           ,1
           ,1
           ,1
           ,0
           ,0
           ,20120101
           ,20221231)
GO


